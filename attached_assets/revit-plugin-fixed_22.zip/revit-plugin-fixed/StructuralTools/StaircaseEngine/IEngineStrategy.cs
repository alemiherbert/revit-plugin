using Autodesk.Revit.DB;

namespace StructuralTools.StaircaseEngine;

/// <summary>
/// Strategy interface for building <see cref="PanelGeometry"/> from a
/// <see cref="StairNode"/>. Each engine handles one run type (or landings).
/// </summary>
public interface IEngineStrategy
{
    /// <summary>
    /// Build one or more panels for the given node, using the cached
    /// <paramref name="context"/> for material + thickness.
    /// </summary>
    List<PanelGeometry> BuildPanels(Document doc, StairNode node, StairParameterContext context);
}

/// <summary>
/// Routes a <see cref="StairNode"/> to the appropriate engine based on its
/// <see cref="StairNodeType"/> and <see cref="RunTag"/>.
/// </summary>
public static class EngineRouter
{
    public static IEngineStrategy GetEngine(StairNode node) =>
        node.Type == StairNodeType.Landing    ? new StraightEngine() :
        node.Tag  == RunTag.WinderRun         ? new WinderEngine()   :
        node.Tag  == RunTag.CurvedRun         ? new CurvedEngine()   :
                                                 new StraightEngine();
}
