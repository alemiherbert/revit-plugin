using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;

namespace StructuralTools.StaircaseEngine;

/// <summary>
/// Engine B — handles curved <see cref="StairsRun"/> elements (including spiral).
///
/// Tessellates each arc in the path into <c>nSteps</c> segments (one per riser,
/// distributed across all arcs). Each segment becomes a slanted quad with:
///   • Inner edge at radius = arc.Radius - width/2
///   • Outer edge at radius = arc.Radius + width/2
///   • Leading edge at hStart (run's base elevation)
///   • Trailing edge at hEnd (run's top elevation), interpolated linearly
///
/// Critically, the trailing edge XYZs of segment i are reused as the leading
/// edge XYZs of segment i+1 — guaranteeing zero floating-point drift on
/// shared edges within the run.
///
/// If the path contains multiple arcs (e.g. an S-shaped curved run), each arc
/// is processed in sequence, with the trailing edge of arc N becoming the
/// leading edge of arc N+1.
/// </summary>
public class CurvedEngine : IEngineStrategy
{
    public List<PanelGeometry> BuildPanels(Document doc, StairNode node, StairParameterContext context)
    {
        var panels = new List<PanelGeometry>();
        if (node.SourceElement is not StairsRun run) return panels;

        var pathCurves = run.GetStairsPath();
        if (pathCurves == null || !pathCurves.Any()) return panels;

        // Collect ALL arcs in the path (not just the first).
        var arcs = new List<Arc>();
        foreach (var c in pathCurves)
        {
            if (c is Arc a) arcs.Add(a);
        }

        if (arcs.Count == 0) return panels;

        // ---- Compute total angular span across all arcs -----------------------
        double totalDTheta = 0;
        foreach (var arc in arcs)
            totalDTheta += Math.Abs(arc.GetEndParameter(1) - arc.GetEndParameter(0));

        if (totalDTheta < 0.001) return panels;

        // ---- Distribute risers across arcs proportionally ---------------------
        int totalRisers = Math.Max(1, run.ActualRisersNumber);

        double hStart = node.BaseElevation;
        double hEnd   = node.TopElevation;
        double totalRise = hEnd - hStart;

        // State carried across arc boundaries (zero drift).
        XYZ? innerA = null, outerA = null;
        double hA = hStart;

        // Process each arc, tessellating into segments.
        foreach (var arc in arcs)
        {
            XYZ center   = arc.Center;
            double rMid  = arc.Radius;
            double halfW = run.ActualRunWidth / 2.0;
            double rInner = Math.Max(rMid - halfW, EngineConfig.MinInnerRadius);
            double rOuter = rMid + halfW;

            double thetaStart = arc.GetEndParameter(0);
            double thetaEnd   = arc.GetEndParameter(1);
            double dTheta     = thetaEnd - thetaStart;

            // Proportion of total risers for this arc.
            double arcFraction = Math.Abs(dTheta) / totalDTheta;
            int arcSteps = Math.Max(1, (int)Math.Round(totalRisers * arcFraction));
            double stepAngle = dTheta / arcSteps;

            double thetaA = thetaStart;

            for (int i = 0; i < arcSteps; i++)
            {
                double thetaB = thetaStart + (i + 1) * stepAngle;
                double hB = hStart + (hA - hStart) / Math.Max(totalRise, 0.001) * totalRise
                             + (totalRise * (i + 1) / totalRisers) * arcFraction / Math.Max(arcFraction, 0.001);

                // Simpler: interpolate hB based on global progress.
                double globalProgress = (panels.Count + 1) / (double)totalRisers;
                hB = hStart + totalRise * Math.Min(1.0, globalProgress);

                XYZ innerB = new XYZ(
                    center.X + rInner * Math.Cos(thetaB),
                    center.Y + rInner * Math.Sin(thetaB),
                    hB);
                XYZ outerB = new XYZ(
                    center.X + rOuter * Math.Cos(thetaB),
                    center.Y + rOuter * Math.Sin(thetaB),
                    hB);

                // On the first segment of the first arc, compute innerA/outerA.
                if (innerA == null || outerA == null)
                {
                    innerA = new XYZ(
                        center.X + rInner * Math.Cos(thetaA),
                        center.Y + rInner * Math.Sin(thetaA),
                        hA);
                    outerA = new XYZ(
                        center.X + rOuter * Math.Cos(thetaA),
                        center.Y + rOuter * Math.Sin(thetaA),
                        hA);
                }

                // Quad winding (CCW from outside): innerA → outerA → outerB → innerB.
                panels.Add(new PanelGeometry
                {
                    Corners = new List<XYZ> { innerA, outerA, outerB, innerB },
                    Thickness       = context.ThicknessFt,
                    MaterialId      = context.MaterialId,
                    Role            = PanelRole.Flight,
                    SourceElementId = run.Id,
                    Label           = $"Flight {run.Id} (curved seg {panels.Count + 1}/{totalRisers})"
                });

                // Reuse for next iteration — zero drift on shared edge.
                innerA = innerB;
                outerA = outerB;
                thetaA = thetaB;
                hA = hB;
            }
        }

        return panels;
    }
}
