using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;

namespace StructuralTools.StaircaseEngine;

/// <summary>
/// Engine C — handles winder <see cref="StairsRun"/> elements.
///
/// Winder runs have an inner radius that may approach zero at the pivot
/// corner. For each step:
///   • Compute the effective inner radius: max(rInner, waist/2).
///   • If rInnerEffective < <see cref="EngineConfig.MinQuadThreshold"/>,
///     emit a TRIANGLE (outerA → outerB → innerMid).
///   • Otherwise emit a quad (same as <see cref="CurvedEngine"/>).
///
/// This prevents degenerate zero-area quads at the pivot while still
/// representing the structural surface continuously. After a triangle is
/// emitted, <c>innerA</c> is updated to <c>innerMid</c> so the next segment
/// continues from the midpoint (no geometric discontinuity).
///
/// If the path contains multiple arcs (e.g. an S-shaped winder), each arc is
/// processed in sequence with shared XYZs across arc boundaries.
/// </summary>
public class WinderEngine : IEngineStrategy
{
    public List<PanelGeometry> BuildPanels(Document doc, StairNode node, StairParameterContext context)
    {
        var panels = new List<PanelGeometry>();
        if (node.SourceElement is not StairsRun run) return panels;

        var pathCurves = run.GetStairsPath();
        if (pathCurves == null || !pathCurves.Any()) return panels;

        // Collect ALL arcs in the path (not just the first).
        var arcs = new List<Arc>();
        foreach (var c in pathCurves)
        {
            if (c is Arc a) arcs.Add(a);
        }

        if (arcs.Count == 0) return panels;

        // ---- Compute total angular span across all arcs -----------------------
        double totalDTheta = 0;
        foreach (var arc in arcs)
            totalDTheta += Math.Abs(arc.GetEndParameter(1) - arc.GetEndParameter(0));

        if (totalDTheta < 0.001) return panels;

        int totalRisers = Math.Max(1, run.ActualRisersNumber);

        double hStart = node.BaseElevation;
        double hEnd   = node.TopElevation;
        double totalRise = hEnd - hStart;

        // Inner-radius floor — prevents collapse to zero at the pivot.
        double rInnerFloor = Math.Max(context.ThicknessFt * 0.5, EngineConfig.MinInnerRadius);

        double halfW = run.ActualRunWidth / 2.0;
        double rOuter = 0;  // computed per-arc
        double rInnerRaw = 0;  // computed per-arc

        // State carried across arc boundaries (zero drift).
        XYZ? innerA = null, outerA = null;
        double hA = hStart;

        // Process each arc.
        foreach (var arc in arcs)
        {
            XYZ center   = arc.Center;
            double rMid  = arc.Radius;
            rOuter = rMid + halfW;
            rInnerRaw = rMid - halfW;

            double thetaStart = arc.GetEndParameter(0);
            double thetaEnd   = arc.GetEndParameter(1);
            double dTheta     = thetaEnd - thetaStart;

            double arcFraction = Math.Abs(dTheta) / totalDTheta;
            int arcSteps = Math.Max(1, (int)Math.Round(totalRisers * arcFraction));
            double stepAngle = dTheta / arcSteps;

            double thetaA = thetaStart;

            for (int i = 0; i < arcSteps; i++)
            {
                double thetaB = thetaStart + (i + 1) * stepAngle;

                // Interpolate hB based on global progress.
                double globalProgress = (panels.Count + 1) / (double)totalRisers;
                double hB = hStart + totalRise * Math.Min(1.0, globalProgress);

                // Effective inner radius for this step (floor prevents collapse).
                double rInnerEff = Math.Max(rInnerRaw, rInnerFloor);

                XYZ outerB = new XYZ(
                    center.X + rOuter * Math.Cos(thetaB),
                    center.Y + rOuter * Math.Sin(thetaB),
                    hB);

                // On the first segment overall, compute innerA/outerA.
                if (innerA == null || outerA == null)
                {
                    innerA = new XYZ(
                        center.X + rInnerEff * Math.Cos(thetaA),
                        center.Y + rInnerEff * Math.Sin(thetaA),
                        hA);
                    outerA = new XYZ(
                        center.X + rOuter * Math.Cos(thetaA),
                        center.Y + rOuter * Math.Sin(thetaA),
                        hA);
                }

                PanelGeometry pg;
                if (rInnerEff < EngineConfig.MinQuadThreshold)
                {
                    // Triangle: outerA → outerB → innerMid.
                    double thetaMid = (thetaA + thetaB) / 2.0;
                    double hMid = (hA + hB) / 2.0;
                    XYZ innerMid = new XYZ(
                        center.X + rInnerEff * Math.Cos(thetaMid),
                        center.Y + rInnerEff * Math.Sin(thetaMid),
                        hMid);

                    pg = new PanelGeometry
                    {
                        Corners = new List<XYZ> { outerA, outerB, innerMid },
                        Thickness       = context.ThicknessFt,
                        MaterialId      = context.MaterialId,
                        Role            = PanelRole.Winder,
                        SourceElementId = run.Id,
                        Label           = $"Winder {run.Id} (tri seg {panels.Count + 1}/{totalRisers})"
                    };

                    innerA = innerMid;
                }
                else
                {
                    // Quad: innerA → outerA → outerB → innerB.
                    XYZ innerB = new XYZ(
                        center.X + rInnerEff * Math.Cos(thetaB),
                        center.Y + rInnerEff * Math.Sin(thetaB),
                        hB);

                    pg = new PanelGeometry
                    {
                        Corners = new List<XYZ> { innerA, outerA, outerB, innerB },
                        Thickness       = context.ThicknessFt,
                        MaterialId      = context.MaterialId,
                        Role            = PanelRole.Winder,
                        SourceElementId = run.Id,
                        Label           = $"Winder {run.Id} (quad seg {panels.Count + 1}/{totalRisers})"
                    };

                    innerA = innerB;
                }

                panels.Add(pg);

                // Always reuse outerB as next outerA.
                outerA = outerB;
                thetaA = thetaB;
                hA = hB;
            }
        }

        return panels;
    }
}
