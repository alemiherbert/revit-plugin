using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using System.IO;

namespace StructuralTools.StaircaseEngine;

/// <summary>
/// Engine A — handles all straight <see cref="StairsRun"/> elements AND
/// all <see cref="StairsLanding"/> elements.
///
/// For a landing: builds a flat polygon panel from <c>GetFootprintBoundary()</c>.
/// For a straight run: builds a 4-corner inclined quad from the stairs path
/// and run width, with the leading edge at <c>BaseElevation</c> and the
/// trailing edge at <c>TopElevation</c>.
/// For a sketched run (multi-segment path): decomposes into flight groups
/// (slanted) and landing groups (flat) based on direction changes.
/// </summary>
public class StraightEngine : IEngineStrategy
{
    /// <summary>
    /// Temporary diagnostics collector. The orchestrator drains this after
    /// each <see cref="BuildPanels"/> call and appends to the summary log.
    /// Also written to a file on the user's Desktop for easy reading.
    /// </summary>
    public static List<string> Diagnostics { get; } = new();

    /// <summary>Path to the diagnostic log file (overwritten each run).</summary>
    private static readonly string DiagFilePath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
        "StructuralTools_StaircaseDiag.txt");

    private static void Diag(string msg)
    {
        System.Diagnostics.Debug.WriteLine(msg);
        Diagnostics.Add(msg);
        try { File.AppendAllText(DiagFilePath, msg + Environment.NewLine); }
        catch { /* ignore file errors */ }
    }

    /// <summary>
    /// Clear the diagnostic file at the start of a run. Call once before any
    /// <see cref="BuildPanels"/> calls in the batch.
    /// </summary>
    public static void ResetDiagFile()
    {
        try { File.WriteAllText(DiagFilePath, ""); }
        catch { /* ignore */ }
    }

    /// <summary>Path to the diagnostic file — shown in the summary dialog.</summary>
    public static string DiagFilePathPublic => DiagFilePath;

    public List<PanelGeometry> BuildPanels(Document doc, StairNode node, StairParameterContext context)
    {
        Diagnostics.Clear();
        return node.SourceElement switch
        {
            StairsLanding landing => BuildLandingPanel(doc, landing, node, context),
            StairsRun run          => BuildRunPanels(doc, run, node, context),
            _ => new List<PanelGeometry>()
        };
    }

    // ---------------------------------------------------------------------
    // Run dispatch — straight vs sketched
    // ---------------------------------------------------------------------

    /// <summary>
    /// Build panels for a <see cref="StairsRun"/>. Dispatches to
    /// <see cref="BuildSketchedRunPanels"/> if the path has multiple segments
    /// (typical for sketched runs covering a dogleg / U-shape in one element),
    /// otherwise falls back to <see cref="BuildStraightRunPanel"/>.
    /// </summary>
    private static List<PanelGeometry> BuildRunPanels(
        Document doc, StairsRun run, StairNode node, StairParameterContext context)
    {
        var pathCurves = run.GetStairsPath();

        // Multi-segment path → sketched run with multiple flights baked in.
        if (pathCurves != null && pathCurves.Count() > 1)
        {
            return BuildSketchedRunPanels(doc, run, node, context);
        }

        return BuildStraightRunPanel(doc, run, node, context);
    }

    // ---------------------------------------------------------------------
    // Landing
    // ---------------------------------------------------------------------

    private static List<PanelGeometry> BuildLandingPanel(
        Document doc, StairsLanding landing, StairNode node, StairParameterContext context)
    {
        var panels = new List<PanelGeometry>();
        double z = node.BaseElevation;

        // Try GetFootprintBoundary().
        CurveLoop? outer = TryGetFootprintBoundary(landing);
        if (outer == null)
        {
            // Fallback: bounding-box rectangle.
            outer = TryGetBoundingBoxRectangle(landing, z);
        }

        if (outer == null) return panels;

        // Extract corners from the loop, projected to z.
        // CurveLoop is already closed (last curve's end == first curve's start),
        // so we only need each curve's start point.
        var corners = new List<XYZ>();
        foreach (var c in outer)
        {
            var p = c.GetEndPoint(0);
            corners.Add(new XYZ(p.X, p.Y, z));
        }

        if (corners.Count < 3) return panels;

        // If non-rectangular (>4 corners), tessellate into triangles via fan triangulation.
        if (corners.Count > 4)
        {
            for (int i = 1; i < corners.Count - 1; i++)
            {
                panels.Add(MakePanel(
                    new[] { corners[0], corners[i], corners[i + 1] },
                    landing, PanelRole.Landing, context, "tri"));
            }
            return panels;
        }

        panels.Add(MakePanel(corners.ToArray(), landing, PanelRole.Landing, context, "land"));
        return panels;
    }

    // ---------------------------------------------------------------------
    // Sketched run (multi-flight — the most common case in practice)
    // ---------------------------------------------------------------------

    /// <summary>
    /// Build panels for a sketched run whose path has multiple segments.
    ///
    /// A sketched run can contain an entire dogleg / U-shape / L-shape as a
    /// single <see cref="StairsRun"/> element.
    ///
    /// Algorithm:
    ///   1. Get the run's footprint boundary via <c>GetFootprintBoundary()</c>.
    ///      This returns the ACTUAL outline of the run (not a centreline
    ///      approximation) — correct dimensions and orientation.
    ///   2. Extract path segments from <c>GetStairsPath()</c> to determine
    ///      flight directions and where landings occur (direction changes).
    ///   3. For each flight group, find the footprint edges parallel to the
    ///      flight direction — those form the flight panel's side edges.
    ///      The leading edge is the footprint edge at the flight's start;
    ///      the trailing edge is at the flight's end.
    ///   4. For each landing group, use the footprint edges in the landing's
    ///      direction.
    ///   5. Lift flight edges to their correct Z (base → top) and build
    ///      slanted panels; keep landing panels flat.
    ///   6. Snap shared edges between consecutive panels.
    ///
    /// This produces panels that match the actual run geometry because they're
    /// derived from the footprint, not from a centreline + assumed width.
    /// </summary>
    private static List<PanelGeometry> BuildSketchedRunPanels(
        Document doc, StairsRun run, StairNode node, StairParameterContext context)
    {
        var panels = new List<PanelGeometry>();

        var pathCurves = run.GetStairsPath()?.ToList();
        if (pathCurves == null || pathCurves.Count == 0) return panels;

        // ---- Extract path segments ------------------------------------------
        var segments = new List<(XYZ start, XYZ end, XYZ dir, double len)>();
        foreach (var c in pathCurves)
        {
            var s = c.GetEndPoint(0);
            var e = c.GetEndPoint(1);
            var d = e - s;
            double l = d.GetLength();
            if (l < 0.001) continue;
            segments.Add((s, e, d.Normalize(), l));
        }

        if (segments.Count == 0) return panels;
        if (segments.Count == 1)
            return BuildStraightRunPanel(doc, run, node, context);

        // =====================================================================
        // DIAGNOSTIC LOGGING (temporary — no geometric changes)
        // Probe GetFootprintBoundary() and GetBoundaries() to learn what
        // the API actually returns for a sketched dogleg run.
        // =====================================================================
        Diag(
            $"[DIAG] Run {run.Id}: sketched-run decomposition — {segments.Count} path segments.");

        for (int i = 0; i < segments.Count; i++)
        {
            var s = segments[i];
            Diag(
                $"[DIAG]   seg {i}: start=({s.start.X:F3},{s.start.Y:F3},{s.start.Z:F3}) " +
                $"end=({s.end.X:F3},{s.end.Y:F3},{s.end.Z:F3}) " +
                $"dir=({s.dir.X:F3},{s.dir.Y:F3},{s.dir.Z:F3}) len={s.len:F3}");
        }

        // Probe GetFootprintBoundary() — count loops + vertices per loop.
        var footprintLoops = TryGetFootprintBoundaries(run);
        if (footprintLoops == null || footprintLoops.Count == 0)
        {
            Diag(
                $"[DIAG]   GetFootprintBoundary(): NOT AVAILABLE or returned 0 loops.");
        }
        else
        {
            Diag(
                $"[DIAG]   GetFootprintBoundary(): {footprintLoops.Count} loop(s).");
            for (int i = 0; i < footprintLoops.Count; i++)
            {
                var loop = footprintLoops[i];
                int vCount = 0;
                foreach (var c in loop) vCount++;
                Diag(
                    $"[DIAG]     loop {i}: {vCount} curves.");

                int vIdx = 0;
                foreach (var c in loop)
                {
                    var p = c.GetEndPoint(0);
                    Diag(
                        $"[DIAG]       v{vIdx}: ({p.X:F3},{p.Y:F3},{p.Z:F3})");
                    vIdx++;
                }
            }
        }

        // Probe GetBoundaries() — does this method exist on StairsRun?
        try
        {
            var boundariesMethod = typeof(StairsRun).GetMethod("GetBoundaries");
            if (boundariesMethod != null)
            {
                Diag(
                    $"[DIAG]   StairsRun.GetBoundaries(): METHOD EXISTS.");
                var result = boundariesMethod.Invoke(run, null);
                if (result is IList<Curve> curves)
                {
                    Diag(
                        $"[DIAG]     returned IList<Curve> with {curves.Count} curve(s).");
                    for (int i = 0; i < Math.Min(curves.Count, 6); i++)
                    {
                        var c = curves[i];
                        var p0 = c.GetEndPoint(0);
                        var p1 = c.GetEndPoint(1);
                        Diag(
                            $"[DIAG]       curve {i}: ({p0.X:F3},{p0.Y:F3},{p0.Z:F3}) " +
                            $"→ ({p1.X:F3},{p1.Y:F3},{p1.Z:F3}) type={c.GetType().Name}");
                    }
                }
                else if (result != null)
                {
                    Diag(
                        $"[DIAG]     returned {result.GetType().Name} (unexpected type).");
                }
                else
                {
                    Diag($"[DIAG]     returned null.");
                }
            }
            else
            {
                Diag(
                    $"[DIAG]   StairsRun.GetBoundaries(): method does NOT exist.");
            }
        }
        catch (Exception ex)
        {
            Diag(
                $"[DIAG]   StairsRun.GetBoundaries(): threw {ex.GetType().Name} — {ex.Message}");
        }

        // Probe other possibly-useful methods.
        foreach (string methodName in new[] { "GetRunOutline", "GetFootprint", "GetProfile",
                                               "GetBoundaryCurves", "GetSideBoundaries" })
        {
            var m = typeof(StairsRun).GetMethod(methodName);
            if (m != null)
            {
                Diag(
                    $"[DIAG]   StairsRun.{methodName}(): EXISTS (return type {m.ReturnType.Name}).");
            }
        }

        // =====================================================================
        // END DIAGNOSTIC LOGGING — existing logic follows.
        // =====================================================================

        if (footprintLoops == null || footprintLoops.Count == 0)
        {
            // Fallback: use the old path+width approach if footprint unavailable.
            return BuildSketchedRunPanelsFromPath(run, node, context, segments);
        }

        var footprint = footprintLoops[0];  // outer loop
        var footprintPts = footprint.Select(c => c.GetEndPoint(0)).ToList();

        // ---- Group path segments by direction --------------------------------
        var groups = new List<List<int>>();
        var currentGroup = new List<int> { 0 };

        for (int i = 1; i < segments.Count; i++)
        {
            double dot = segments[i].dir.DotProduct(segments[i - 1].dir);
            if (dot > 0.5)
            {
                currentGroup.Add(i);
            }
            else
            {
                groups.Add(currentGroup);
                currentGroup = new List<int> { i };
            }
        }
        groups.Add(currentGroup);

        // ---- Classify groups as flight or landing ----------------------------
        var overallDir = (segments[^1].end - segments[0].start).Normalize();
        var groupIsFlight = new bool[groups.Count];

        for (int g = 0; g < groups.Count; g++)
        {
            var groupDir = segments[groups[g][0]].dir;
            double dotOverall = Math.Abs(groupDir.DotProduct(overallDir));
            groupIsFlight[g] = dotOverall > 0.5;
        }

        bool anyLanding = Array.Exists(groupIsFlight, f => !f);
        if (!anyLanding && groups.Count > 1)
        {
            for (int g = 0; g < groups.Count; g++)
                groupIsFlight[g] = (g % 2 == 0);
        }

        // ---- Compute total flight length (for proportional rise) -----------
        double baseZ = node.BaseElevation;
        double topZ  = node.TopElevation;
        double totalRise = topZ - baseZ;

        double totalFlightLength = 0;
        var groupLengths = new double[groups.Count];

        for (int g = 0; g < groups.Count; g++)
        {
            double groupLen = groups[g].Sum(i => segments[i].len);
            groupLengths[g] = groupLen;
            if (groupIsFlight[g]) totalFlightLength += groupLen;
        }

        if (totalFlightLength < 0.001)
            return BuildSketchedRunPanelsFromPath(run, node, context, segments);

        // ---- Build panels for each group using actual footprint corners -----
        double currentZ = baseZ;

        for (int g = 0; g < groups.Count; g++)
        {
            var group = groups[g];
            double groupLen = groupLengths[g];
            bool isFlight = groupIsFlight[g];

            if (groupLen < EngineConfig.MinEdgeFt) continue;

            var groupStart = segments[group[0]].start;
            var groupEnd   = segments[group[^1]].end;
            var groupDir   = (groupEnd - groupStart).Normalize();

            // Find footprint corners that belong to this group:
            // corners whose projection onto groupDir falls within the group's
            // extent along the path.
            double groupStartProj = groupStart.DotProduct(groupDir);
            double groupEndProj   = groupEnd.DotProduct(groupDir);
            double loProj = Math.Min(groupStartProj, groupEndProj);
            double hiProj = Math.Max(groupStartProj, groupEndProj);

            // Expand slightly to include corners right at the boundary.
            double tol = 0.05;
            var groupCorners = footprintPts
                .Where(p =>
                {
                    double proj = p.DotProduct(groupDir);
                    return proj >= loProj - tol && proj <= hiProj + tol;
                })
                .ToList();

            if (groupCorners.Count < 3) continue;

            if (isFlight)
            {
                // Slanted panel: distribute rise proportionally.
                double flightRise = totalRise * (groupLen / totalFlightLength);
                double flightBaseZ = currentZ;
                double flightTopZ  = currentZ + flightRise;

                // Assign Z based on each corner's projection along groupDir.
                // Corners near groupStart → flightBaseZ; corners near groupEnd → flightTopZ.
                var slantedCorners = groupCorners.Select(p =>
                {
                    double proj = p.DotProduct(groupDir);
                    double t = (proj - loProj) / Math.Max(hiProj - loProj, 0.001);
                    t = Math.Max(0, Math.Min(1, t));
                    double z = flightBaseZ + t * (flightTopZ - flightBaseZ);
                    return new XYZ(p.X, p.Y, z);
                }).ToList();

                panels.Add(new PanelGeometry
                {
                    Corners         = OrderCornersCCW(slantedCorners),
                    Thickness       = context.ThicknessFt,
                    MaterialId      = context.MaterialId,
                    Role            = PanelRole.Flight,
                    SourceElementId = run.Id,
                    Label           = $"Flight {run.Id} (sketched flight {g + 1})"
                });
                currentZ = flightTopZ;
            }
            else
            {
                // Flat landing panel at currentZ.
                var flatCorners = groupCorners
                    .Select(p => new XYZ(p.X, p.Y, currentZ))
                    .ToList();

                panels.Add(new PanelGeometry
                {
                    Corners         = OrderCornersCCW(flatCorners),
                    Thickness       = context.ThicknessFt,
                    MaterialId      = context.MaterialId,
                    Role            = PanelRole.Landing,
                    SourceElementId = run.Id,
                    Label           = $"Landing {run.Id} (sketched landing {g + 1})"
                });
            }
        }

        SnapConsecutivePanelEdges(panels);
        return panels;
    }

    /// <summary>
    /// Fallback: build sketched-run panels from path + width when
    /// <c>GetFootprintBoundary()</c> is unavailable.
    ///
    /// For sketched runs, <c>ActualRunWidth</c> is used for ALL panels
    /// (flights and landing) — the landing in a dogleg is the same width as
    /// the flights, just a flat panel connecting them. The bounding-box
    /// width is NOT used because the run's bbox includes both flights,
    /// which would produce a landing panel that's far too wide.
    /// </summary>
    private static List<PanelGeometry> BuildSketchedRunPanelsFromPath(
        StairsRun run, StairNode node, StairParameterContext context,
        List<(XYZ start, XYZ end, XYZ dir, double len)> segments)
    {
        var panels = new List<PanelGeometry>();

        // Group by direction.
        var groups = new List<List<int>>();
        var currentGroup = new List<int> { 0 };
        for (int i = 1; i < segments.Count; i++)
        {
            if (segments[i].dir.DotProduct(segments[i - 1].dir) > 0.5)
                currentGroup.Add(i);
            else
            {
                groups.Add(currentGroup);
                currentGroup = new List<int> { i };
            }
        }
        groups.Add(currentGroup);

        var overallDir = (segments[^1].end - segments[0].start).Normalize();
        var groupIsFlight = new bool[groups.Count];
        for (int g = 0; g < groups.Count; g++)
        {
            var groupDir = segments[groups[g][0]].dir;
            groupIsFlight[g] = Math.Abs(groupDir.DotProduct(overallDir)) > 0.5;
        }
        if (!Array.Exists(groupIsFlight, f => !f) && groups.Count > 1)
            for (int g = 0; g < groups.Count; g++)
                groupIsFlight[g] = (g % 2 == 0);

        double baseZ = node.BaseElevation;
        double topZ  = node.TopElevation;
        double totalRise = topZ - baseZ;
        double totalFlightLength = 0;
        var groupLengths = new double[groups.Count];
        for (int g = 0; g < groups.Count; g++)
        {
            groupLengths[g] = groups[g].Sum(i => segments[i].len);
            if (groupIsFlight[g]) totalFlightLength += groupLengths[g];
        }
        if (totalFlightLength < 0.001) return panels;

        // Use the run width from the instance property or type parameter.
        // For sketched runs, ActualRunWidth is often 0 — try the type parameter.
        double runWidth = StairParameterExtractor.GetRunWidth(run);

        if (runWidth < EngineConfig.MinEdgeFt)
        {
            // Width not found via property or type parameter.
            // Log ALL width-related parameters so we can find the right one.
            Diag($"[DIAG] Run width not found via ActualRunWidth or type parameters.");
            StairParameterExtractor.LogWidthParameters(run, Diagnostics);

            // Last-resort fallback: default 4 ft.
            runWidth = EngineConfig.FallbackRunWidth;
            Diag($"[DIAG] Using default fallback width {runWidth:F3} ft.");
        }
        else
        {
            Diag($"[DIAG] Using run width {runWidth:F3} ft (from "
                 + (run.ActualRunWidth > 0 ? "ActualRunWidth" : "type parameter")
                 + ") for all panels.");
        }

        double halfWidth = runWidth / 2.0;

        double currentZ = baseZ;

        for (int g = 0; g < groups.Count; g++)
        {
            double groupLen = groupLengths[g];
            if (groupLen < EngineConfig.MinEdgeFt) continue;

            var groupStart = segments[groups[g][0]].start;
            var groupEnd   = segments[groups[g][^1]].end;

            if (groupIsFlight[g])
            {
                double flightRise = totalRise * (groupLen / totalFlightLength);
                var panel = BuildSlantedPanel(
                    groupStart, groupEnd, currentZ, currentZ + flightRise,
                    halfWidth, run, context, $"sketched flight {g + 1} (path)");
                if (panel != null)
                {
                    panels.Add(panel);
                    Diag($"[DIAG]   Built flight panel {g + 1}: " +
                         $"{groupStart.X:F3},{groupStart.Y:F3} (z={currentZ:F3}) → " +
                         $"{groupEnd.X:F3},{groupEnd.Y:F3} (z={currentZ + flightRise:F3}), " +
                         $"width={runWidth:F3}, rise={flightRise:F3}");
                    currentZ += flightRise;
                }
                else
                {
                    Diag($"[DIAG]   Flight panel {g + 1}: BuildSlantedPanel returned null.");
                }
            }
            else
            {
                var panel = BuildFlatPanel(
                    groupStart, groupEnd, currentZ,
                    halfWidth, run, context, $"sketched landing {g + 1} (path)");
                if (panel != null)
                {
                    panels.Add(panel);
                    Diag($"[DIAG]   Built landing panel {g + 1}: " +
                         $"{groupStart.X:F3},{groupStart.Y:F3} → " +
                         $"{groupEnd.X:F3},{groupEnd.Y:F3} (z={currentZ:F3}), " +
                         $"width={runWidth:F3}");
                }
                else
                {
                    Diag($"[DIAG]   Landing panel {g + 1}: BuildFlatPanel returned null.");
                }
            }
        }

        SnapConsecutivePanelEdges(panels);
        return panels;
    }

    /// <summary>
    /// Order a list of XY points counter-clockwise (for valid CurveLoop winding).
    /// Uses the convex-hull-free centroid-angle method.
    /// </summary>
    private static List<XYZ> OrderCornersCCW(List<XYZ> pts)
    {
        if (pts.Count <= 3) return pts;

        // Compute centroid in XY.
        double cx = pts.Average(p => p.X);
        double cy = pts.Average(p => p.Y);

        // Sort by angle from centroid (in XY plane).
        return pts
            .OrderBy(p => Math.Atan2(p.Y - cy, p.X - cx))
            .ToList();
    }

    // ---------------------------------------------------------------------
    // Panel construction helpers (shared by straight + sketched)
    // ---------------------------------------------------------------------

    /// <summary>
    /// Build a slanted (inclined) quad panel from a path start/end and
    /// base/top elevations. Returns null if any edge is too short.
    /// </summary>
    private static PanelGeometry? BuildSlantedPanel(
        XYZ pathStart, XYZ pathEnd,
        double baseZ, double topZ,
        double halfWidth,
        StairsRun run, StairParameterContext context, string label)
    {
        XYZ dir = pathEnd - pathStart;
        if (dir.GetLength() < EngineConfig.MinEdgeFt) return null;
        dir = dir.Normalize();

        XYZ perp = new XYZ(-dir.Y, dir.X, 0) * halfWidth;

        var bl = new XYZ(pathStart.X - perp.X, pathStart.Y - perp.Y, baseZ);
        var br = new XYZ(pathStart.X + perp.X, pathStart.Y + perp.Y, baseZ);
        var tr = new XYZ(pathEnd.X   + perp.X, pathEnd.Y   + perp.Y, topZ);
        var tl = new XYZ(pathEnd.X   - perp.X, pathEnd.Y   - perp.Y, topZ);

        // Validate edges.
        if (bl.DistanceTo(br) < EngineConfig.MinEdgeFt) return null;
        if (tr.DistanceTo(tl) < EngineConfig.MinEdgeFt) return null;
        if (br.DistanceTo(tr) < EngineConfig.MinEdgeFt) return null;

        return new PanelGeometry
        {
            Corners         = new List<XYZ> { bl, br, tr, tl },
            Thickness       = context.ThicknessFt,
            MaterialId      = context.MaterialId,
            Role            = PanelRole.Flight,
            SourceElementId = run.Id,
            Label           = $"Flight {run.Id} ({label})"
        };
    }

    /// <summary>
    /// Build a flat (horizontal) quad panel from a path start/end at a given Z.
    /// Returns null if any edge is too short.
    /// </summary>
    private static PanelGeometry? BuildFlatPanel(
        XYZ pathStart, XYZ pathEnd, double z,
        double halfWidth,
        StairsRun run, StairParameterContext context, string label)
    {
        XYZ dir = pathEnd - pathStart;
        if (dir.GetLength() < EngineConfig.MinEdgeFt) return null;
        dir = dir.Normalize();

        XYZ perp = new XYZ(-dir.Y, dir.X, 0) * halfWidth;

        var c1 = new XYZ(pathStart.X - perp.X, pathStart.Y - perp.Y, z);
        var c2 = new XYZ(pathStart.X + perp.X, pathStart.Y + perp.Y, z);
        var c3 = new XYZ(pathEnd.X   + perp.X, pathEnd.Y   + perp.Y, z);
        var c4 = new XYZ(pathEnd.X   - perp.X, pathEnd.Y   - perp.Y, z);

        if (c1.DistanceTo(c2) < EngineConfig.MinEdgeFt) return null;
        if (c3.DistanceTo(c4) < EngineConfig.MinEdgeFt) return null;
        if (c2.DistanceTo(c3) < EngineConfig.MinEdgeFt) return null;

        return new PanelGeometry
        {
            Corners         = new List<XYZ> { c1, c2, c3, c4 },
            Thickness       = context.ThicknessFt,
            MaterialId      = context.MaterialId,
            Role            = PanelRole.Landing,
            SourceElementId = run.Id,
            Label           = $"Landing {run.Id} ({label})"
        };
    }

    // ---------------------------------------------------------------------
    // Width computation (rotation-correct)
    // ---------------------------------------------------------------------

    /// <summary>
    /// Get the run width perpendicular to the given path direction.
    /// Uses <see cref="StairsRun.ActualRunWidth"/> first; falls back to the
    /// bounding-box extent projected onto the perpendicular direction, then
    /// to <see cref="EngineConfig.FallbackRunWidth"/>.
    /// </summary>
    private static double GetRunWidth(StairsRun run, XYZ pathDir)
    {
        double w = run.ActualRunWidth;
        if (w >= EngineConfig.MinEdgeFt) return w;

        // Fallback: project bbox corners onto the perpendicular direction.
        double bboxWidth = GetBboxWidthPerpendicularTo(run, pathDir);
        if (bboxWidth >= EngineConfig.MinEdgeFt) return bboxWidth;

        return EngineConfig.FallbackRunWidth;
    }

    /// <summary>
    /// Compute the element's extent perpendicular to the given direction by
    /// projecting the bounding-box corners onto the perpendicular axis.
    /// Works correctly for rotated stairs (unlike Math.Min(dx, dy)).
    /// </summary>
    private static double GetBboxWidthPerpendicularTo(Element elem, XYZ pathDir)
    {
        var bb = elem.get_BoundingBox(null);
        if (bb == null) return 0;

        // Perpendicular to pathDir in XY plane.
        XYZ perpDir = new XYZ(-pathDir.Y, pathDir.X, 0);

        var corners = new[]
        {
            new XYZ(bb.Min.X, bb.Min.Y, 0),
            new XYZ(bb.Max.X, bb.Min.Y, 0),
            new XYZ(bb.Max.X, bb.Max.Y, 0),
            new XYZ(bb.Min.X, bb.Max.Y, 0)
        };

        double minProj = double.MaxValue, maxProj = double.MinValue;
        var origin = new XYZ(corners[0].X, corners[0].Y, 0);

        foreach (var c in corners)
        {
            double proj = (c - origin).DotProduct(perpDir);
            minProj = Math.Min(minProj, proj);
            maxProj = Math.Max(maxProj, proj);
        }

        return maxProj - minProj;
    }

    // ---------------------------------------------------------------------
    // Internal sketched-run connectivity snapping
    // ---------------------------------------------------------------------

    /// <summary>
    /// Snap shared edges between consecutive panels produced by a sketched run.
    /// For each pair (panel[i], panel[i+1]), snap panel[i]'s trailing edge
    /// (highest-Z 2 corners) to panel[i+1]'s leading edge (lowest-Z 2 corners)
    /// if they're within <see cref="EngineConfig.EdgeSnapTolerance"/>.
    /// </summary>
    private static void SnapConsecutivePanelEdges(List<PanelGeometry> panels)
    {
        for (int i = 0; i < panels.Count - 1; i++)
        {
            var lower = panels[i];
            var upper = panels[i + 1];

            // Get lower's top-edge (highest-Z) corner indices.
            var lowerTopIndices = lower.Corners
                .Select((c, idx) => (c, idx))
                .OrderByDescending(t => t.c.Z)
                .Take(2)
                .Select(t => t.idx)
                .ToList();

            // Get upper's bottom-edge (lowest-Z) corner indices.
            var upperBottomIndices = upper.Corners
                .Select((c, idx) => (c, idx))
                .OrderBy(t => t.c.Z)
                .Take(2)
                .Select(t => t.idx)
                .ToList();

            // For each upper bottom corner, find nearest lower top corner.
            foreach (int ui in upperBottomIndices)
            {
                var uc = upper.Corners[ui];
                XYZ? nearest = null;
                double nearestDist = double.MaxValue;

                foreach (int li in lowerTopIndices)
                {
                    double d = uc.DistanceTo(lower.Corners[li]);
                    if (d < nearestDist)
                    {
                        nearestDist = d;
                        nearest = lower.Corners[li];
                    }
                }

                if (nearest != null && nearestDist < EngineConfig.EdgeSnapTolerance)
                {
                    upper.Corners[ui] = nearest;
                }
            }
        }
    }

    // ---------------------------------------------------------------------
    // Straight run (single-segment path)
    // ---------------------------------------------------------------------

    private static List<PanelGeometry> BuildStraightRunPanel(
        Document doc, StairsRun run, StairNode node, StairParameterContext context)
    {
        var panels = new List<PanelGeometry>();

        // ---- Get the run's horizontal path (start → end) ---------------------
        var pathCurves = run.GetStairsPath();
        if (pathCurves == null || !pathCurves.Any())
        {
            Diag(
                $"[StructuralTools] Run {run.Id}: GetStairsPath() returned empty.");
            return panels;
        }

        var allCurves = pathCurves.ToList();
        var p0 = allCurves.First().GetEndPoint(0);
        var p1 = allCurves.Last().GetEndPoint(1);

        double pathLength = (p1 - p0).GetLength();
        if (pathLength < EngineConfig.MinEdgeFt)
        {
            Diag(
                $"[StructuralTools] Run {run.Id}: path too short ({pathLength:F4} ft).");
            return panels;
        }

        XYZ dir = (p1 - p0).Normalize();

        // ---- Get the run width (rotation-correct) ----------------------------
        double runWidth = GetRunWidth(run, dir);
        double halfWidth = runWidth / 2.0;
        XYZ perp = new XYZ(-dir.Y, dir.X, 0) * halfWidth;

        double baseZ = node.BaseElevation;
        double topZ  = node.TopElevation;

        // ---- Build 4 corners --------------------------------------------------
        var bl = new XYZ(p0.X - perp.X, p0.Y - perp.Y, baseZ);
        var br = new XYZ(p0.X + perp.X, p0.Y + perp.Y, baseZ);
        var tr = new XYZ(p1.X + perp.X, p1.Y + perp.Y, topZ);
        var tl = new XYZ(p1.X - perp.X, p1.Y - perp.Y, topZ);

        // ---- Validate all edge lengths ---------------------------------------
        double leadEdge  = bl.DistanceTo(br);
        double trailEdge = tr.DistanceTo(tl);
        double sideEdge  = br.DistanceTo(tr);

        if (leadEdge < EngineConfig.MinEdgeFt || trailEdge < EngineConfig.MinEdgeFt || sideEdge < EngineConfig.MinEdgeFt)
        {
            Diag(
                $"[StructuralTools] Run {run.Id}: edge too short — " +
                $"lead={leadEdge:F3} ft, trail={trailEdge:F3} ft, side={sideEdge:F3} ft " +
                $"(min={EngineConfig.MinEdgeFt} ft). Width={runWidth:F3}, pathLen={pathLength:F3}.");
            return panels;
        }

        panels.Add(MakePanel(
            new[] { bl, br, tr, tl },
            run, PanelRole.Flight, context, "run"));
        return panels;
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    private static PanelGeometry MakePanel(
        IList<XYZ> corners, Element source,
        PanelRole role, StairParameterContext context, string suffix)
    {
        return new PanelGeometry
        {
            Corners         = corners.ToList(),
            Thickness       = context.ThicknessFt,
            MaterialId      = context.MaterialId,
            Role            = role,
            SourceElementId = source.Id,
            Label           = $"{role} {source.Id} ({suffix})"
        };
    }

    private static CurveLoop? TryGetFootprintBoundary(Element elem)
    {
        var loops = TryGetFootprintBoundaries(elem);
        return loops != null && loops.Count > 0 ? loops[0] : null;
    }

    /// <summary>
    /// Get ALL footprint boundary loops from <c>GetFootprintBoundary()</c>.
    /// Returns null if the method is unavailable or fails.
    /// </summary>
    private static IList<CurveLoop>? TryGetFootprintBoundaries(Element elem)
    {
        try
        {
            var method = elem.GetType().GetMethod("GetFootprintBoundary");
            if (method?.Invoke(elem, null) is not IList<CurveLoop> loops) return null;
            return loops;
        }
        catch { return null; }
    }

    private static CurveLoop? TryGetBoundingBoxRectangle(Element elem, double z)
    {
        var bb = elem.get_BoundingBox(null);
        if (bb == null) return null;

        var c1 = new XYZ(bb.Min.X, bb.Min.Y, z);
        var c2 = new XYZ(bb.Max.X, bb.Min.Y, z);
        var c3 = new XYZ(bb.Max.X, bb.Max.Y, z);
        var c4 = new XYZ(bb.Min.X, bb.Max.Y, z);

        return CurveLoop.Create(new[]
        {
            Line.CreateBound(c1, c2),
            Line.CreateBound(c2, c3),
            Line.CreateBound(c3, c4),
            Line.CreateBound(c4, c1)
        });
    }
}
